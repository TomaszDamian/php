<?php require 'partials/header.view.php'; ?>
	<h1>About <?= $company?> </h1>
<?php require 'partials/footer.view.php'; ?>