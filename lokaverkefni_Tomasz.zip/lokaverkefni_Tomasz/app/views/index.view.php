<?php require 'partials/header.view.php'; ?>
<div class="p-8">
	<h1>Home Page</h1>
</div>
<?php require 'partials/footer.view.php'; ?>