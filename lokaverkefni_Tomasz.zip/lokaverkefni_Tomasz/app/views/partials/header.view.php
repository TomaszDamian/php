<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>doc</title>
	<link href="https://cdn.jsdelivr.net/npm/tailwindcss/dist/tailwind.min.css" rel="stylesheet">
	<link rel="stylesheet" href="/public/style.css">
</head>
<body>
    <?php require 'nav.view.php'; ?>