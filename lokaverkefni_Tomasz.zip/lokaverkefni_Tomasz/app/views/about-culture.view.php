<?php require 'partials/header.view.php'; ?>
	<h1>our culture</h1>
<?php require 'partials/footer.view.php'; ?>